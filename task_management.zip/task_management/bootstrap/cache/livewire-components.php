<?php return array (
  'category' => 'App\\Http\\Livewire\\Category',
  'task' => 'App\\Http\\Livewire\\Task',
);