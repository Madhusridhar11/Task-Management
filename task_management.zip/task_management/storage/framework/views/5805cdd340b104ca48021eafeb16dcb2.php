<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tasks Management - Admin Panel</title>
    <meta name="author" content="Yasser Elgammal">
    <meta name="description" content="">

    <!-- Tailwind -->
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <style>
        @import url('https://fonts.googleapis.com/css?family=Karla:400,700&display=swap');

        .font-family-karla {
            font-family: karla;
        }

        .bg-sidebar {
            background: #aaaaaa;
        }

        .cta-btn {
            color: #ffa500;
        }

        .upgrade-btn {
            background: #ff9000;
        }

        .upgrade-btn:hover {
            background: #818589;
        }

        .active-nav-link {
            
            background: #aaaaaa;
        }

        .nav-item:hover {
            background: #818589;
        }

        .account-link:hover {
            background: #818589;
        }
    </style>
    <style>
        @import url(https://cdnjs.cloudflare.com/ajax/libs/MaterialDesign-Webfont/5.3.45/css/materialdesignicons.min.css);

        .active\:bg-gray-50:active {
            --tw-bg-opacity: 1;
            background-color: rgba(249, 250, 251, var(--tw-bg-opacity));
        }
    </style>
    <?php echo \Livewire\Livewire::styles(); ?>

</head>

<body class="bg-gray-200 font-family-karla flex">

    <aside class="relative bg-sidebar h-screen w-64 hidden sm:block shadow-xl">
        <div class="p-4">
            <a href="<?php echo e(route('admin.index')); ?>"
                class="text-white text-3xl font-semibold uppercase hover:text-gray-300">

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin-only')): ?>
                    Admin
                <?php else: ?>
                    Employee
                <?php endif; ?>

            </a>
            
        </div>
        <nav class="text-white text-base font-semibold">
            <a href="<?php echo e(route('admin.index')); ?>"
                class="<?php echo e(request()->routeIs('admin.index') ? 'active-nav-link' : 'opacity-85 hover:opacity-100'); ?> flex items-center text-white py-4 pl-6 nav-item">
                <i class="fas fa-tachometer-alt mr-3"></i>
                Dashboard
            </a>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin-only')): ?>
                <a href="<?php echo e(route('admin.users.index')); ?>"
                    class="<?php echo e(request()->routeIs('admin.users.index') ? 'active-nav-link' : 'opacity-85 hover:opacity-100'); ?> flex items-center text-white py-4 pl-6 nav-item">
                    <i class="fas fa-user mr-3"></i>
                    User
                </a>
                <a href="<?php echo e(route('admin.categories.index')); ?>"
                    class="<?php echo e(request()->routeIs('admin.categories.index') ? 'active-nav-link' : 'opacity-85 hover:opacity-100'); ?> flex items-center text-white py-4 pl-6 nav-item">
                    <i class="fas fa-code-branch mr-3"></i>
                    Status
                </a>
                <a href="<?php echo e(route('admin.tasks.index')); ?>"
                    class="<?php echo e(request()->routeIs('admin.tasks.index') ? 'active-nav-link' : 'opacity-85 hover:opacity-100'); ?> flex items-center text-white py-4 pl-6 nav-item">
                    <i class="fas fa-list mr-3"></i>
                    Tasks
                </a>
            <?php endif; ?>
            <a href="<?php echo e(route('admin.auth_tasks.index')); ?>"
                class="<?php echo e(request()->routeIs('admin.auth_tasks.index') ? 'active-nav-link' : 'opacity-85 hover:opacity-100'); ?> flex items-center text-white py-4 pl-6 nav-item">
                <i class="fas fa-tasks mr-3"></i>
                My Assigned Tasks
            </a>


        </nav>
        <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <button
                class="absolute w-full upgrade-btn bottom-0 active-nav-link text-white flex items-center justify-center py-4">
                <i class="fas fa-arrow-circle-left mr-3"></i>
                Sign Out
            </button>
        </form>
    </aside>

    <div class="w-full flex flex-col h-screen overflow-y-hidden">

        <!-- Desktop Header -->
        <header class="w-full items-center bg-white py-2 px-6 hidden sm:flex">
            <div class="w-full text-lg">Tasks Management</div>
            <div class="w-1/2"></div>
            <div x-data="{ isOpen: false }" class="relative w-1/2 flex justify-end">
                <button @click="isOpen = !isOpen"
                    class="realtive z-10 w-12 h-12 rounded-full overflow-hidden border-4 border-gray-400 hover:border-gray-300 focus:border-gray-300 focus:outline-none">
                    <img src="<?php echo e(asset('import/assets/profile-pic-dummy.png')); ?>">
                </button>
                <button x-show="isOpen" @click="isOpen = false"
                    class="h-full w-full fixed inset-0 cursor-default"></button>
                <div x-show="isOpen" class="absolute w-32 bg-white rounded-lg shadow-lg py-2 mt-16">
                    
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <button class="block px-4 py-2 account-link hover:text-white w-full text-left">Sign Out</button>
                    </form>
                </div>
            </div>
        </header>

        <!-- Mobile Header & Nav -->
        <header x-data="{ isOpen: false }" class="w-full bg-sidebar py-5 px-6 sm:hidden">
            <div class="flex items-center justify-between">
                <a href="index.html" class="text-white text-3xl font-semibold uppercase hover:text-gray-300">Admin</a>
                <button @click="isOpen = !isOpen" class="text-white text-3xl focus:outline-none">
                    <i x-show="!isOpen" class="fas fa-bars"></i>
                    <i x-show="isOpen" class="fas fa-times"></i>
                </button>
            </div>

            <!-- Dropdown Nav -->
            <nav :class="isOpen ? 'flex' : 'hidden'" class="flex flex-col pt-4">
                <a href="index.html" class="flex items-center active-nav-link text-white py-2 pl-4 nav-item">
                    <i class="fas fa-tachometer-alt mr-3"></i>
                    Dashboard
                </a>


                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button
                        class="flex items-center text-white opacity-85 hover:opacity-100 py-2 pl-4 nav-item w-full text-left">
                        <i class="fas fa-sign-out-alt mr-3"></i>
                        Sign Out
                    </button>
                </form>

            </nav>

        </header>

        <?php if($errors->any()): ?>
            <div role="alert">
                <div class="bg-red-500 text-white font-bold rounded-t px-4 py-2 mx-4">
                    Validation Errors
                </div>
                <div class="border border-t-0 border-red-400 rounded-b bg-red-100 px-4 py-3 text-red-700 mx-4">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        <?php endif; ?>
        
        <?php echo e($slot); ?>


        
    </div>

    </div>

    <!-- AlpineJS -->
    <script defer src="https://cdnjs.cloudflare.com/ajax/libs/alpinejs/2.3.0/alpine-ie11.js"></script>
    <!-- Font Awesome -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/js/all.min.js"
        integrity="sha256-KzZiKy0DWYsnwMF+X1DvQngQ2/FxF7MF3Ff72XcpuPs=" crossorigin="anonymous"></script>

    <?php echo \Livewire\Livewire::scripts(); ?>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\task_management\resources\views/admin/layouts/admin.blade.php ENDPATH**/ ?>