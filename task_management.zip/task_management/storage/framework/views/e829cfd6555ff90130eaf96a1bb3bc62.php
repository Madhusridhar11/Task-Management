<style>
    input[type=file] {
  width: 218px;
  max-width: 100%;
  color: #444;
  padding: 5px;
  background: #fff;
  border-radius: 10px;
  border: 1px solid #555;
}

</style>

<div class="w-full h-screen overflow-x-hidden border-t flex flex-col">
    <main class="w-full flex-grow p-6">
        <h1 class="w-full text-3xl text-black pb-6">Tasks</h1>
        <div class="w-full mt-1 ">
            <form method="POST" wire:submit.prevent="store">
                <?php echo csrf_field(); ?>
                <div class="grid gap-6 mb-6 md:grid-cols-2">
                    <div class="mb-1">
                        <label for="name" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Task
                            title</label>
                        <input type="text" id="title" value="<?php echo e(old('title')); ?>"
                            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                             required name="title" wire:model="title">
                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="bg-yellow-300 text-red-700"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-1">
                        <label for="due_date" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Due
                            Date</label>
                        <input type="date" id="due_date" value="<?php echo e(old('due_date')); ?>"
                            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                            required name="due_date" wire:model="due_date">
                        <?php $__errorArgs = ['due_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="bg-yellow-300 text-red-700"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-1">
                        <label for="chooseCategory"
                            class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Choose Status</label>
                        <select
                            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                            id="chooseCategory" name="category_id" wire:model="category_id" required>
                            <option value="">Select Status</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="bg-yellow-300 text-red-700"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-1">
                        <label for="assignedUser"
                            class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Assigne to user</label>
                        <select
                            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                            id="assignedUser" name="assigned_to_user_id" wire:model="assigned_to_user_id" required>
                            <option value="">Select User</option>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['assigned_to_user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="bg-yellow-300 text-red-700"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-2">
                    <label class="block text-sm text-gray-600" for="description">Description</label>
                    <textarea
                        class="w-full bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                        id="message" name="description" wire:model="description" required><?php echo e(old('description')); ?></textarea>
                        <input id="file-upload" name="file-upload" type="file">
                </div>
                <div class="mb-2">
                    <label class="block text-sm text-gray-600" for="comments">Comments</label>
                    <textarea
                        class="w-full bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                        id="comments" name="comments" wire:model="comments" required><?php echo e(old('comments')); ?></textarea>
                    
                </div>
                </div>
                
              
            </div>

                <button class="px-4 py-1 text-white font-light tracking-wider bg-blue-600 rounded">Add
                    Task</button>
            </form>
        </div>
        <?php if (isset($component)) { $__componentOriginala0e57685145cd3f8dede0ca77793a25b = $component; } ?>
<?php $component = App\View\Components\SessionMessage::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('session-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\SessionMessage::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala0e57685145cd3f8dede0ca77793a25b)): ?>
<?php $component = $__componentOriginala0e57685145cd3f8dede0ca77793a25b; ?>
<?php unset($__componentOriginala0e57685145cd3f8dede0ca77793a25b); ?>
<?php endif; ?>

        <p class="text-xl pb-3 flex items-center">
            <i class="fas fa-list mr-3"></i> Tasks Records
        </p>
        
        <div class="bg-white overflow-auto">
            <table class="text-left w-full border-collapse">
                <thead>
                    <tr>
                        <th
                            class="py-4 px-6 bg-grey-lightest font-bold uppercase text-sm text-grey-dark border-b border-grey-light">
                            ID</th>
                        <th
                            class="py-4 px-6 bg-grey-lightest font-bold uppercase text-sm text-grey-dark border-b border-grey-light">
                            Title</th>
                        <th
                            class="py-4 px-6 bg-grey-lightest font-bold uppercase text-sm text-grey-dark border-b border-grey-light">
                            Added by</th>
                        <th
                            class="py-4 px-6 bg-grey-lightest font-bold uppercase text-sm text-grey-dark border-b border-grey-light">
                            Assigned to</th>
                        <th
                            class="py-4 px-6 bg-grey-lightest font-bold uppercase text-sm text-grey-dark border-b border-grey-light">
                            Last Updated</th>
                        <th
                            class="py-4 px-6 bg-grey-lightest font-bold uppercase text-sm text-grey-dark border-b border-grey-light">
                            Work status</th>
                          <!--  <th
                            class="py-4 px-6 bg-grey-lightest font-bold uppercase text-sm text-grey-dark border-b border-grey-light">
                            Last Updated</th>-->
                        <th
                            class="py-4 px-6 bg-grey-lightest font-bold uppercase text-sm text-grey-dark border-b border-grey-light">
                            Manage</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="hover:bg-grey-lighter">
                            <td class="py-4 px-6 border-b border-grey-light"><?php echo e($task->id); ?></td>
                            <td class="py-4 px-6 border-b border-grey-light"><?php echo e($task->title); ?></td>
                            <td class="py-4 px-6 border-b border-grey-light"><?php echo e($task->user->name); ?></td>
                            <td
                                class="py-4 px-6 border-b border-grey-light <?php echo e($task->assignedUser->name ?? 'text-red-700'); ?>">
                                <?php echo e($task->assignedUser->name ?? 'Not Assigned'); ?></td>
                            <td class="py-4 px-6 border-b border-grey-light"><?php echo e($task->updated_at); ?></td>
                            <td class="py-4 px-6 border-b border-grey-light"><?php echo e($task->completed ? "Yes" : "No"); ?></td>
                           <!-- <td class="py-4 px-6 border-b border-grey-light"><?php echo e($task->updated_at); ?></td>-->

                            <td class="py-4 px-6 border-b border-grey-light">
                                <button class="px-4 py-1 text-white font-light tracking-wider bg-green-600 rounded"
                                    type="button"
                                    onclick="location.href='<?php echo e(route('admin.tasks.edit', $task->id)); ?>';">Edit</button>

                                
                                <form type="submit" method="POST" style="display: inline"
                                    action="<?php echo e(route('admin.tasks.destroy', $task->id)); ?>"
                                    onsubmit="return confirm('Are you sure?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="px-4 py-1 text-white font-light tracking-wider bg-red-600 rounded"
                                        type="submit">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo e($tasks->links()); ?>

        </div>
    </main>
</div>
<?php /**PATH C:\xampp\htdocs\task_management\resources\views/livewire/task.blade.php ENDPATH**/ ?>