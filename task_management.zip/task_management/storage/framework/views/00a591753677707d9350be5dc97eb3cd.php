<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="w-full h-screen overflow-x-hidden border-t flex flex-col">
        <main class="w-full flex-grow p-6">
            <h1 class="w-full text-3xl text-black pb-6">Show Task</h1>

            <div class="w-full mt-4">
                <p class="text-xl pb-3 flex items-center">
                    <i class="fas fa-list mr-3"></i> Task Details
                </p>

                <div class="grid gap-6 mb-6 md:grid-cols-2">
                    <div class="mb-1">
                        <label for="name" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Task
                            title</label>
                        <?php echo e($task->title); ?>

                    </div>
                    <div class="mb-1">
                        <label for="due_date" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Due
                            Date</label>
                        <?php echo e($task->due_date); ?>

                    </div>
                    <div class="mb-1">
                        <label for="name" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Is Completed</label>
                        <?php echo e($task->completed ? "Yes" : "No"); ?>

                    </div>
                    <!--<div class="mb-1">
                        <label for="name" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Completed Date</label>
                        <?php echo e($task->completed_at ?? "None"); ?>

                    </div>-->
                    <div class="mb-1">
                        <label for="Category"
                            class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Status</label>
                        <?php echo e($task->category->name); ?>

                    </div>
                    <div class="mb-1">
                        <label for="assignedUser"
                            class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Assigne to</label>
                        <?php echo e($task->user->name); ?>

                    </div>
                    <div class="mb-1">
                        <label for="name" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                            Created By</label>
                        <?php echo e($task->user->name); ?>

                    </div>
                    
                </div>
                <div class="mb-2">
                    <label class="block text-sm text-gray-600" for="description">Description</label>
                    <?php echo e($task->description); ?>

                </div>

                <?php if(!$task->completed): ?>
                    <form type="submit" method="POST" style="display: inline"
                        action="<?php echo e(route('admin.complete_task.store', $task->id)); ?>"
                        onsubmit="return confirm('Are you sure?')">
                        <?php echo csrf_field(); ?>
                        <button class="px-4 py-1 text-white font-light tracking-wider bg-green-600 rounded"
                            type="submit">Mark Completed</button>
                    </form>
                <?php endif; ?>

            </div>
        </main>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\task_management\resources\views/admin/task/show_single_assign_task.blade.php ENDPATH**/ ?>