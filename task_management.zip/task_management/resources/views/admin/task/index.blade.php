<x-admin-layout>

    <livewire:task>

</x-admin-layout>
