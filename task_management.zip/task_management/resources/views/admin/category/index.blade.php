<x-admin-layout>

    <livewire:category>

</x-admin-layout>
